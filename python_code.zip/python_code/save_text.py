def save_text(filename,edges):
    def save_txt():
        with open(filename, "w") as f:
            for edge in edges:
                f.write(str(edge[0]) + " " + str(edge[1]) + "\n")
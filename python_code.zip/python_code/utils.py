import load_edge

from tqdm import tqdm
def remove_and_sort1(edge_key_list):
    removed_list=[]
    print("正在去重")
    for item in tqdm(edge_key_list):
        if item[0]!=item[1]:
            if item not in removed_list:
                removed_list.append(item)
    edge_list_sort=[[int(x[0]),int(x[1])]if int(x[0])<int(x[1]) else [int(x[1]),int(x[0])] for x in removed_list]
    sort_d = [value for index, value in sorted(enumerate(edge_list_sort), key=lambda d:d[1])]
    #排序后去除最后一遍重复边
    result=[]
    print("去除重复边和自环")
    for i in tqdm(sort_d):
        if i not in result and i[0]!=i[1]:
            result.append(i)
    return result
def reindex(edge_list):
    print("正在处理索引压缩")
    node_unique=[]
    for it in tqdm(edge_list) :
        if it[0] not in node_unique:
            node_unique.append(it[0])
        if it[1] not in node_unique:
            node_unique.append(it[1])
    node_unique.sort()
    anti_dict={}

    node_unique_dict={}
    for i,ele in enumerate(node_unique):
        node_unique_dict[ele]=i
        anti_dict[i]=ele

    edge_list_new=[[node_unique_dict[x[0]],node_unique_dict[x[1]]] for x in edge_list]
    edge_list_unique=[]
    for i in tqdm(range(len(edge_list_new))):
        if edge_list_new[i] not in edge_list_unique and edge_list_new[i][0]!=edge_list_new[i][1]:
            edge_list_unique.append(edge_list_new[i])
    
    return edge_list_unique,node_unique_dict,anti_dict
def get_origin_index(edge_list,node_unique_dict):
    origin_index=[]
    for i in edge_list:
        origin_index.append([node_unique_dict[i[0]],node_unique_dict[i[1]]])
    return origin_index
def get_oringin_node_index(node_lists,node_unique_dict):
    origin_node_index=[]
    for i in node_lists:
        origin_node_index.append(node_unique_dict[i])
    return origin_node_index

def get_contains_edges(nodes,edge_list):
    contains_edges=[]
    for edge in edge_list:
        if edge[0] in nodes and edge[1] in nodes:
            contains_edges.append(edge)
    return contains_edges


def mat_transfer(file_name):
    edge_list=load_edge.load_edge(file_name)
    
    edge_list_unique_sort=remove_and_sort1(edge_list)
    edge_list_unique,node_unique_dict,antidict=reindex(edge_list_unique_sort)
    return edge_list_unique,antidict
def load_dict(file_name):
    dicts={}
    with open(file_name,'r') as f:
        for line in f.readlines():
            line=line.strip()
            line=line.split(' ')
            dicts[line[0]]=line[1]

    return dicts    
def load_nodes(file_name):
    nodes=[]
    with open(file_name,'r') as f:
        for line in f.readlines():
            line=line.strip()
            nodes.append(line)
    return nodes
def load_edge(file_name):
    edge_list=[]
    with open(file_name,'r') as f:
        for line in f.readlines():
            line=line.strip()
            line=line.split(' ')
            edge_list.append([line[0],line[1]])
    return edge_list
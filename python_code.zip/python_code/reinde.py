def reindex(edge_list):
    print("���ڴ�������ѹ��")
    node_unique=[]
    for it in edge_list:
        if it[0] not in node_unique:
            node_unique.append(it[0])
        if it[1] not in node_unique:
            node_unique.append(it[1])
    node_unique.sort()
    node_unique_dict={}
    for i,ele in enumerate(node_unique):
        node_unique_dict[ele]=i
    edge_list_new=[[node_unique_dict[x[0]],node_unique_dict[x[1]]] for x in edge_list]
    # edge_list_unique=[]
    # for i in tqdm(range(len(edge_list_new))):
    #     if edge_list_new[i] not in edge_list_unique:
    #         edge_list_unique.append(edge_list_new[i])
    return edge_list_new,node_unique_dict